package org.yocto.sdk.ide.natures;

import org.yocto.sdk.ide.YoctoSDKPlugin;

public class YoctoSDKEmptyProjectNature extends YoctoSDKProjectNature {

	public static final  String YoctoSDK_EMPTY_NATURE_ID = YoctoSDKPlugin.getUniqueIdentifier() + ".YoctoSDKEmptyNature";
}
